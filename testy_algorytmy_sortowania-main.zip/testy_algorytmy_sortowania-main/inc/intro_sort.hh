#ifndef INTRO_SORT_HH
#define INTRO_SORT_HH

#include "quick_sort.hh"

// C++ implementation of Introsort algorithm
 
//#include <bits/stdc++.h>
using namespace std;

class intro_sort
{
private:
public:
    // A utility function to swap the values pointed by
// the two pointers
void swapValue(data_from_file* a, data_from_file* b);
/* Function to sort an array using insertion sort*/
void InsertionSort(data_from_file arr[], data_from_file* begin, data_from_file* end);
// A function to partition the array and return
// the partition point
data_from_file* Partition(data_from_file arr[], int low, int high); 
// A function that find the middle of the
// values pointed by the pointers a, b, c
// and return that pointer
data_from_file* MedianOfThree(data_from_file* a, data_from_file* b, data_from_file* c);
// A Utility function to perform intro sort
void IntrosortUtil(data_from_file arr[], data_from_file* begin, data_from_file* end,
                   int depthLimit);
/* Implementation of introsort*/
void introSort(data_from_file arr[], int begin_temp, int end_temp);

};

#endif


 
