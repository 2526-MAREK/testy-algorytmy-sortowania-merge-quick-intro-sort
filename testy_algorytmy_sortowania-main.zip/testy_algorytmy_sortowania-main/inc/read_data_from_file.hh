#ifndef READ_DATA_FROM_FILE_HH
#define READ_DATA_FROM_FILE_HH

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cmath>
#include <chrono>

/*#define SIZE_OF_10K_data 10'000
#define SIZE_OF_100K_data 100'000
#define SIZE_OF_200K_data 200'000
#define SIZE_OF_300K_data 300'000
#define SIZE_OF_400K_data 400'000
#define SIZE_OF_500K_data 500'000
#define SIZE_OF_600K_data 600'000
#define SIZE_OF_700K_data 700'000
#define SIZE_OF_800K_data 800'000
#define SIZE_OF_900K_data 900'000
#define SIZE_OF_1M_data 1'000'000*/

#define SIZE_OF_10K_DATA 10'000
#define SIZE_OF_100K_DATA 100'000
#define SIZE_OF_200K_DATA 200'000
#define SIZE_OF_300K_DATA 300'000
#define SIZE_OF_400K_DATA 400'000
#define SIZE_OF_500K_DATA 500'000
#define SIZE_OF_600K_DATA 600'000
#define SIZE_OF_700K_DATA 700'000
#define SIZE_OF_800K_DATA 800'000
#define SIZE_OF_900K_DATA 900'000
#define SIZE_OF_1000K_DATA 1'000'000

struct data_from_file{
    float number_of_ranking;
    std::string title;
};

class read_data_from_file{
private:
    std::fstream file_temp;
public:
    data_from_file *_10K_data;
    data_from_file *_100K_data;
    //dodatkowe struktury do polepszenia dokładności wykresu analizy złożoności algorytmu
    data_from_file *_200K_data;
    data_from_file *_300K_data;
    data_from_file *_400K_data;
    //
    data_from_file *_500K_data;
    //dodatkowe struktury do polepszenia dokładności wykresu analizy złożoności algorytmu
    data_from_file *_600K_data;
    data_from_file *_700K_data;
    data_from_file *_800K_data;
    data_from_file *_900K_data;
    //
    data_from_file *_1000K_data;
    std::vector<data_from_file> _MAX_data;
    /*data_from_file* _MAX_data;
    unsigned int number_of_data;*/
    read_data_from_file();
    ~read_data_from_file();
    //void fn_read_data_from_file(const char* name_of_file_temp);
    //read_data_from_file(unsigned int number_of_data_temp);
    read_data_from_file(const char* name_of_file_temp);
    void algorithm_complexity_saving_to_csv_file(unsigned int number_of_data, auto filtering_time);
    void test_filtr_read_data_from_file(const char* name_of_file_temp);
};
#endif