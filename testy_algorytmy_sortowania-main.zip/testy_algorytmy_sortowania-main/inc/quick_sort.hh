#ifndef QUCIK_SORT_HH
#define QUCIK_SORT_HH

#include "read_data_from_file.hh"

class quick_sort
{
private:
public:
    void quickSort(data_from_file *tab, int begin_tab, int end_tab);
};

#endif