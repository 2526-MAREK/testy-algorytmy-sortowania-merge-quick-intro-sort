#ifndef MERGE_SORT_HH
#define MERGE_SORT_HH

#include "read_data_from_file.hh"

class merge_sort
{
private:
public:
void merge(data_from_file* tab, int begin_tab, int mid_tab, int end_tab);
void mergeSort(data_from_file* tab, int begin_tab, int end_tab);
};
#endif