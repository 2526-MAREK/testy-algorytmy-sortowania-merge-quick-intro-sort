#ifndef TEST_ALGORITHM_HH
#define TEST_ALGORITHM_HH

#include "merge_sort.hh"
#include "quick_sort.hh"
#include "intro_sort.hh"

#define MEDIAN_TO_FILE 1
#define AVARAGE_VALUE_TO_FILE 1

class test_algorithm
{
public:
    void validate_the_sorted_number_of_ranking(const char* name_algorithm, data_from_file* tab,unsigned int begin_data, unsigned int data_size);
    unsigned int calculated_avarage_value_of_ranking(data_from_file* tab,unsigned int begin_data, unsigned int data_size);
    unsigned int calculated_median_of_ranking(data_from_file* tab,unsigned int begin_data, unsigned int data_size);
};

//name_of_object_algorithm##_sort.name_of_algorithm##Sort(data_test_##name_of_algorithm##_sort.number_of_data, 0,SIZE_OF##number_of_data-1);     \
//#define TEST_ALGORITHM(name_of_algorithm,name_of_object_algorithm,number_of_data) 
#define TEST_ALGORITHM(name_of_algorithm,name_of_object_algorithm,number_of_data, name_of_algorithm_string,number_of_data_string) \
{ \
    test_algorithm test_alg; \
    name_of_algorithm##_sort name_of_object_algorithm##_sort; \
    auto start = std::chrono::high_resolution_clock::now(); \
    name_of_object_algorithm##_sort.name_of_algorithm##Sort(data_test_##name_of_algorithm##_sort._##number_of_data##_data, 0,SIZE_OF_##number_of_data##_DATA-1);     \
    auto stop = std::chrono::high_resolution_clock::now(); \
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(stop - start);       \
    std::cout<<"czas sortowania " number_of_data_string " danych z pomoca " name_of_algorithm_string " sort: " <<duration.count()/1000.0<<" [s]"<<std::endl; \
    if( file.good() ) \
        { \
            file <<name_of_algorithm_string<<","<< SIZE_OF_##number_of_data##_DATA << ","<<duration.count()/1000.0<<std::endl; \
            if(MEDIAN_TO_FILE) \
                file <<"Median: "<<test_alg.calculated_median_of_ranking(data_test_##name_of_algorithm##_sort._##number_of_data##_data, 0,SIZE_OF_##number_of_data##_DATA)<<std::endl; \
            if(AVARAGE_VALUE_TO_FILE) \
                file <<"Avarage_value: "<<test_alg.calculated_avarage_value_of_ranking(data_test_##name_of_algorithm##_sort._##number_of_data##_data, 0,SIZE_OF_##number_of_data##_DATA)<<std::endl; \
            file.flush(); \
        } \
    test_alg.validate_the_sorted_number_of_ranking(name_of_algorithm_string, data_test_##name_of_algorithm##_sort._##number_of_data##_data, 0,SIZE_OF_##number_of_data##_DATA);         \
}

#define TEST_ALGORITHM_MAX(name_of_algorithm,name_of_object_algorithm, name_of_algorithm_string) \
{ \
    test_algorithm test_alg_max; \
    name_of_algorithm##_sort name_of_object_algorithm##_sort; \
    auto start = std::chrono::high_resolution_clock::now(); \
    name_of_object_algorithm##_sort.name_of_algorithm##Sort(data_test_##name_of_algorithm##_sort._MAX_data.data(), 0,data_test_##name_of_algorithm##_sort._MAX_data.size()-1);     \
    auto stop = std::chrono::high_resolution_clock::now(); \
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(stop - start);       \
    std::cout<<"czas sortowania " <<data_test_##name_of_algorithm##_sort._MAX_data.size() << " danych z pomoca " name_of_algorithm_string " sort: " <<duration.count()/1000.0<<" [s]"<<std::endl; \
    if( file.good() ) \
        { \
            file <<name_of_algorithm_string<<","<< data_test_##name_of_algorithm##_sort._MAX_data.size() << ","<<duration.count()/1000.0<<std::endl; \
            if(MEDIAN_TO_FILE) \
                file <<"Median: "<<test_alg_max.calculated_median_of_ranking(data_test_##name_of_algorithm##_sort._MAX_data.data(), 0,data_test_##name_of_algorithm##_sort._MAX_data.size())<<std::endl; \
            if(AVARAGE_VALUE_TO_FILE) \
                file <<"Avarage_value: "<<test_alg_max.calculated_avarage_value_of_ranking(data_test_##name_of_algorithm##_sort._MAX_data.data(), 0,data_test_##name_of_algorithm##_sort._MAX_data.size())<<std::endl; \
            file.flush(); \
        } \
        test_alg_max.validate_the_sorted_number_of_ranking(name_of_algorithm_string, data_test_##name_of_algorithm##_sort._MAX_data.data(), 0,data_test_##name_of_algorithm##_sort._MAX_data.size());         \
}

#define TEST_ALGORITHM_BEGIN(name_of_algoritm, name_of_algorithm_string,name_of_file_with_data_input_string) \
    read_data_from_file data_test_##name_of_algoritm##_sort(name_of_file_with_data_input_string); \
    TEST_ALGORITHM(name_of_algoritm,name_of_algoritm##_obj,10K,name_of_algorithm_string,"10K") \
    TEST_ALGORITHM(name_of_algoritm,name_of_algoritm##_obj,100K,name_of_algorithm_string,"100K") \
    TEST_ALGORITHM(name_of_algoritm,name_of_algoritm##_obj,200K,name_of_algorithm_string,"200K") \
    TEST_ALGORITHM(name_of_algoritm,name_of_algoritm##_obj,300K,name_of_algorithm_string,"300K") \
    TEST_ALGORITHM(name_of_algoritm,name_of_algoritm##_obj,400K,name_of_algorithm_string,"400K")  \
    TEST_ALGORITHM(name_of_algoritm,name_of_algoritm##_obj,500K,name_of_algorithm_string,"500K") \
    TEST_ALGORITHM(name_of_algoritm,name_of_algoritm##_obj,600K,name_of_algorithm_string,"600K") \
    TEST_ALGORITHM(name_of_algoritm,name_of_algoritm##_obj,700K,name_of_algorithm_string,"700K") \
    TEST_ALGORITHM(name_of_algoritm,name_of_algoritm##_obj,800K,name_of_algorithm_string,"800K") \
    TEST_ALGORITHM(name_of_algoritm,name_of_algoritm##_obj,900K,name_of_algorithm_string,"900K") \
    TEST_ALGORITHM(name_of_algoritm,name_of_algoritm##_obj,1000K,name_of_algorithm_string,"1000K") \
    TEST_ALGORITHM_MAX(name_of_algoritm,name_of_algoritm##_obj,name_of_algorithm_string )

#endif