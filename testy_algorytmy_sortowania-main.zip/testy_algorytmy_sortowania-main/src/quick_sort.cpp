#include "quick_sort.hh"
void quick_sort::quickSort(data_from_file *tab, int begin_tab, int end_tab)
{
    if(end_tab <= begin_tab) return;
	
	int i = begin_tab - 1, j = end_tab + 1, 
	pivot = tab[(begin_tab+end_tab)/2].number_of_ranking; //wybieramy punkt odniesienia
	
	while(1)
	{
		//szukam elementu wiekszego lub rownego pivot stojacego
		//po prawej stronie wartosci pivot
		while(pivot>tab[++i].number_of_ranking);
		
		//szukam elementu mniejszego lub rownego pivot stojacego
		//po lewej stronie wartosci pivot
		while(pivot<tab[--j].number_of_ranking);
		
		//jesli liczniki sie nie minely to zamień elementy ze soba
		//stojace po niewlasciwej stronie elementu pivot
		if( i <= j)
			//funkcja swap zamienia wartosciami tab[i] z tab[j]
			std::swap(tab[i],tab[j]);
		else
			break;
	}

	if(j > begin_tab)
	quickSort(tab, begin_tab, j);
	if(i < end_tab)
	quickSort(tab, i, end_tab);
}