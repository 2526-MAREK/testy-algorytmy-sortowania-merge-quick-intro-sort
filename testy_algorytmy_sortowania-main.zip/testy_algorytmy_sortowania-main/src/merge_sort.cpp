#include "merge_sort.hh"

void merge_sort::merge(data_from_file* tab, int begin_tab, int mid_tab, int end_tab)
{
	int left_size = mid_tab - begin_tab + 1;
	int rigth_size = end_tab - mid_tab;
 
	//Tablice pomocnicze
	data_from_file* tab_left = new data_from_file[left_size];
	data_from_file* tab_rigth = new data_from_file[rigth_size];
 
	// Kopiowanie danych do tablic pomocniczych
	for (int x = 0; x < left_size; ++x)
		tab_left[x] = tab[begin_tab + x];
	for (int y = 0; y < rigth_size; y++)
		tab_rigth[y] = tab[mid_tab + 1 + y];
 
	int index_left = 0;
	int index_rigth = 0;
	int curr_index;// = begin_tab;

	//Łączenie tablic rigth i left
    // z pomocą funkcji for przechodzimy przez wszystkie pola 3 tablic czyli,
    // tablica wyjściowa(tab), tablica lewa(tab_left) i tablica prawa(tab_rigth), 
    //zaczynając od ich początków
	for (curr_index = begin_tab; index_left < left_size && index_rigth < rigth_size;
    curr_index++)
	{
        //jeśli obecny ranking w tablicy lewej jest mnijeszy lub równy rankigowi w prawej 
        //tablicy to przypisujemy do tablicy wyjściowej(posortowanej) wartość rankingu w
        // lewej tablicy 
		if (tab_left[index_left].number_of_ranking <= 
        tab_rigth[index_rigth].number_of_ranking) 
			tab[curr_index] = tab_left[index_left++];
		else // jeśli ranking w prawej tablicy jest mnieszy od rankingu w lewej 
        //tablicy to przypisujemy ten ranking z prawej tablicy
        // do tablicy wyjściowej(posortowanej)
			tab[curr_index] = tab_rigth[index_rigth++];
	}
 
	//Jeśli w tablicy tab_left pozostały jeszcze jakieś elementy
	while (index_left < left_size) //przechodzimy po pozostałych elementach w lewej tablicy 
		tab[curr_index++] = tab_left[index_left++];
 
	//Jeśli w tablicy tab_rigth pozostały jeszcze jakieś elementy
	//kopiujemy je
	while (index_rigth < rigth_size)
		tab[curr_index++] = tab_rigth[index_rigth++];
 
	delete[] tab_left;
	delete[] tab_rigth;
}
 
 
void merge_sort::mergeSort(data_from_file* tab, int begin_tab, int end_tab) {

	//dopóki zostanie jeden element w podanym zakresie danych (begin_tab ; end_tab)
	if (end_tab > begin_tab) { 

		//znajdujemy środek naszego zakresu danych 
		int mid_tab = (begin_tab + end_tab) / 2; 

		//sortujemy za pomocą merge sort pierwszy zakres danych (merge sort 1 MG1)
		mergeSort(tab, begin_tab, mid_tab); 

		//sortujemy za pomocą merge sort drugi zakres danych (merge sort 2 MG2)
		mergeSort(tab, mid_tab + 1, end_tab); 

		//łączymy dwie posortowane połówki w w dwóch poprzednich linijkach, 
		//jednocześnie je sortując (MG)
		merge(tab, begin_tab, mid_tab, end_tab); 
	}
}