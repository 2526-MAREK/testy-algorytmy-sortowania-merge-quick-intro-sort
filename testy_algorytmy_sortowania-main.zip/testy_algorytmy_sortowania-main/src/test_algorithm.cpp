#include "test_algorithm.hh"

void test_algorithm::validate_the_sorted_number_of_ranking(const char* name_algorithm, data_from_file* tab,unsigned int begin_data, unsigned int data_size)
{
    for(unsigned int i = begin_data; i<data_size-1; ++i)
    {
        if(tab[i].number_of_ranking>tab[i+1].number_of_ranking)   
        {
            std::cerr<<"Tablica nie prawidlowo posortowana przez "<<name_algorithm<<"w zestawie danych "<<data_size << " !!!"<<std::endl;
        }
    }
}

unsigned int test_algorithm::calculated_median_of_ranking(data_from_file* tab,unsigned int begin_data, unsigned int data_size)
{
    unsigned int mid_tab = (begin_data+data_size)/2;;
    if(data_size%2 == 0) //parzysta liczba liczb w zbiorze
    {
        return (tab[mid_tab-1].number_of_ranking+tab[mid_tab].number_of_ranking)/2;            
    }
    else //nieparzyta liczba liczb w zbiorze
    {
        return tab[mid_tab].number_of_ranking;
    }

}

unsigned int test_algorithm::calculated_avarage_value_of_ranking(data_from_file* tab,unsigned int begin_data, unsigned int data_size)
{
    float avarage_value_temp = 0;
    for(unsigned int i = begin_data; i<data_size-1; ++i)
    {
        avarage_value_temp = avarage_value_temp + tab[i].number_of_ranking;
    }            

    return avarage_value_temp/data_size;
}