#include "intro_sort.hh"

//Funkcja zamieniająca dwa wskaźniki adresami
void intro_sort:: swapValue(data_from_file* a, data_from_file* b)
{
    data_from_file* temp = a;
    a = b;
    b = temp;
}
 
//Funkcja sortownia tablicy za pomocą sortowania przez wstawienie 
void intro_sort::InsertionSort(data_from_file arr[], data_from_file* begin, data_from_file* end)
{

    //Ustalenie pierwszego indeksu lewej i prawej tablicy
    int left = begin - arr;
    int right = end - arr;
 
    for (int i = left + 1; i <= right; i++) {
        int key = arr[i].number_of_ranking;
        int j = i - 1;
 
        /* Przenieś elementy arr[0..i-1], które są
                 większa niż klucz, o jedną pozycję do przodu
                 ich aktualnej pozycji */
        while (j >= left && arr[j].number_of_ranking > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1].number_of_ranking = key;
    }
 
    return;
}
 
// A function to partition the array and return
// the partition point
data_from_file* intro_sort::Partition(data_from_file arr[], int low, int high)
{
    int pivot = arr[high].number_of_ranking; // pivot
    int i = (low - 1); // Indeks mniejszego elementu
 
    for (int j = low; j <= high - 1; j++) {
        // Jeśli bieżący element jest mniejszy niż lub równa się pivotowi
        if (arr[j].number_of_ranking <= pivot) {
            // inkrementacja indexu mniejszego elementu
            i++;
 
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[i + 1], arr[high]);
    return (arr + i + 1);
}
 
// Funkcja, która znajduje mediane
// wartości wskazywane przez wskaźniki a, b, c
// i zwróć ten wskaźnik
data_from_file* intro_sort::MedianOfThree(data_from_file* a, data_from_file* b, data_from_file* c)
{
    if (a->number_of_ranking < b->number_of_ranking && b->number_of_ranking < c->number_of_ranking)
        return (b);

    if (a->number_of_ranking < c->number_of_ranking && c->number_of_ranking <= b->number_of_ranking)
        return (c);
 
    if (b->number_of_ranking <= a->number_of_ranking && a->number_of_ranking < c->number_of_ranking)
        return (a);
 
    if (b->number_of_ranking < c->number_of_ranking && c->number_of_ranking <= a->number_of_ranking)
        return (c);
 
    if (c->number_of_ranking <= a->number_of_ranking && a->number_of_ranking < b->number_of_ranking)
        return (a);
 
    if (c->number_of_ranking <= b->number_of_ranking && b->number_of_ranking <= a->number_of_ranking)
        return (b);
}

// Kopiowanie poddrzewa zakorzenionego w węźle i, którym jest
// indeks w arr[]
void heapify(data_from_file arr[], int size_of_heap, int i)
{
    int largest = i; // Zainicjuj największy jako root
    int l = 2 * i + 1; // left = 2*i + 1
    int r = 2 * i + 2; // right = 2*i + 2
 
    // Jeśli lewe część jest większa niż root
    if (l < size_of_heap && arr[l].number_of_ranking > arr[largest].number_of_ranking)
        largest = l;
 
    // Jeśli prawa część jest do tej pory większe niż największe
    if (r < size_of_heap && arr[r].number_of_ranking > arr[largest].number_of_ranking)
        largest = r;
    
    // Jeśli największy nie jest root
    if (largest != i) {
        swap(arr[i], arr[largest]);
 
        // Rekursywnie stosuj zmienione drzewo podrzędne
        heapify(arr, size_of_heap, largest);
    }
}
 
//główna funkcja do stosowania sortowanie sterty 
void heapSort(data_from_file arr[], int n)
{
    // Zbuduj stertę (przestaw tablicę)
    for (int i = n / 2 - 1; i >= 0; i--)
        heapify(arr, n, i);
 
    // Jeden po drugim wyodrębnij element ze sterty
    for (int i = n - 1; i > 0; i--) {
       // Przenieś bieżący root na koniec
        swap(arr[0], arr[i]);
 
       // wywołanie max heapify na zredukowanej stercie
        heapify(arr, i, 0);
    }
}

// Funkcja Utility do sortowania wstępów
void intro_sort::IntrosortUtil(data_from_file arr[], data_from_file* begin, data_from_file* end,
                   int depthLimit)
{
    // Policz liczbę elementów
    int size = end - begin;
 
    // Jeśli rozmiar danych jest mały, wykonaj sortowanie przez wstawianie
    if (size < 16) {
        InsertionSort(arr, begin, end);
        return;
    }
 
    // Jeśli głębokość wynosi zero, użyj sortowania sterty
    if (depthLimit == 0) {
        heapSort(arr, size);
        return;
    }
 
    // W przeciwnym razie użyj koncepcji mediany trzech, aby
     // znajdź dobry pivot
    data_from_file* pivot
        = MedianOfThree(begin, begin + size / 2, end);
 
    // Zamień wartości wskazywane przez dwa wskaźniki
    swapValue(pivot, end);
 
    //Wykonaj Sortowanie Szybkie
    data_from_file* partitionPoint
        = Partition(arr, begin - arr, end - arr);
    IntrosortUtil(arr, begin, partitionPoint - 1,
                  depthLimit - 1);
    IntrosortUtil(arr, partitionPoint + 1, end,
                  depthLimit - 1);
 
    return;
}
 
//Implementacja Intro Sort
void intro_sort::introSort(data_from_file arr[], int begin_temp, int end_temp)
{
    data_from_file* begin = arr+begin_temp;
    data_from_file* end = arr+end_temp;
    int depthLimit = 2 * log(end - begin);
 
    // Wykonaj rekursywnie Intro Sort 
    IntrosortUtil(arr, begin, end, depthLimit);
 
    return;
}