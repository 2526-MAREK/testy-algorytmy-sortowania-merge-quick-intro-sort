#include "read_data_from_file.hh"

read_data_from_file::read_data_from_file() : _MAX_data(), file_temp("analiza_zloznosci_algorytmu_filtrowania_i_przeszukiwnia_danych.csv", std::ios::out )        
{
    _10K_data = new data_from_file[SIZE_OF_10K_DATA];
    _100K_data = new data_from_file[SIZE_OF_100K_DATA];
    _200K_data = new data_from_file[SIZE_OF_200K_DATA];
    _300K_data = new data_from_file[SIZE_OF_300K_DATA];
    _400K_data = new data_from_file[SIZE_OF_400K_DATA];
    _500K_data = new data_from_file[SIZE_OF_500K_DATA];
    _600K_data = new data_from_file[SIZE_OF_600K_DATA];
    _700K_data = new data_from_file[SIZE_OF_700K_DATA];
    _800K_data = new data_from_file[SIZE_OF_900K_DATA];
    _900K_data = new data_from_file[SIZE_OF_900K_DATA];
    _1000K_data = new data_from_file[SIZE_OF_1000K_DATA];
}

/*void read_data_from_file::fn_read_data_from_file(const char* name_of_file_temp)
{
    std::string one_line_file;
    std::fstream file( "projekt2_dane.csv", std::ios::in ); //zakładamy, że plik istnieje

    if(!file.good())
    { 
        std::cout<<"Nie mozna otworzyc pliku"<<std::endl;
    }

    unsigned int found_comma_first;
    unsigned int found_comma_second;
    //while (!file.eof())
    //{
        getline( file, one_line_file ); //wczytanie CAŁEGO jednego wiersza danych
        found_comma_first = one_line_file.find(".");
        found_comma_second = one_line_file.find(".", found_comma_first+1);
        std::cout<<"found comma first: "<< found_comma_first<<std::endl;
        std::cout<<"found comma second: "<< found_comma_second<<std::endl;
    //}
}*/

read_data_from_file::read_data_from_file(const char* name_of_file_temp) : read_data_from_file()
{
    std::fstream file( name_of_file_temp, std::ios::in ); //zakładamy, że plik istnieje

    if(!file.good())
    { 
        std::cout<<"Nie mozna otworzyc pliku"<<std::endl;
    }

    unsigned int number_of_line_file = 0;    
    unsigned int number_of_save_expression = 0;  

    auto start = std::chrono::high_resolution_clock::now();   
    auto stop = std::chrono::high_resolution_clock::now();   
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(stop - start);  

    auto start_filtring_duration = std::chrono::high_resolution_clock::now();            
    //uznajmy to za początek algorytmu przeszukiwania 
    /*Nasz algorytm jest zalezny tylko i wyłacznie od ilości filtrowanych danych, nasza pętla while nie zawiera metod lub funkcji które są zalezne od naszego zbioru danych, więc złożoność naszego algorytmu będzie liniowa w czasie */
    while (!file.eof()) //n 
    {
        std::string one_line_file;  // 1
        std::size_t found_comma_first;  // 1
        std::size_t found_comma_last; // 1
        std::string expression_before_first_comma; // 1
        std::string expression_before_last_comma; // 1
        std::string expression_after_last_comma; // 1
        ++number_of_line_file; // 1
        
        getline( file, one_line_file ); //wczytanie CAŁEGO jednego wiersza danych, zlozonosc ~n

        found_comma_first = one_line_file.find(","); // n
        found_comma_last = one_line_file.rfind(","); // n

        if(one_line_file[0] == ' ') // 1
        {}
        else{
            unsigned int number_of_empty_char = 0; // 1
            for(unsigned int i = 0; i<found_comma_first;++i) // n
            {
                expression_before_first_comma += one_line_file[i]; // 1
                if(one_line_file[i] == ' ')    // 1
                    ++number_of_empty_char; // 1
            }
            //wyrazenie jest puste, 1
            if(expression_before_first_comma.size() == number_of_empty_char){ 
            }                  
            else //sprawdzamy kolejne wyrazenie przed nastepnym przecinkiem
            {
                if(found_comma_first+1 == found_comma_last){ //wyrazenie typu ,,cos tam , 1
                }   
                else
                {
                    number_of_empty_char = 0; //1
                    for(unsigned int i = found_comma_first+1; i<found_comma_last;++i) //n
                    {
                        expression_before_last_comma += one_line_file[i]; //1
                        if(one_line_file[i]     == ' ')    //1
                            ++number_of_empty_char; //1
                    }
                    //wyrazenie jest puste, 1       
                    if(expression_before_last_comma.size() == number_of_empty_char){ 
                    }                       
                    else //sprawdzamy wyrazenie za ostatnim przecinikeim 
                    {
                        //po ostatnim przecinku nie ma juz nic , 1
                        if(found_comma_last == one_line_file.size()-1){ 
                        }  
                        else                            
                        {
                            number_of_empty_char = 0; // 1
                            // n
                            for(unsigned int i = found_comma_last+1; i<one_line_file.size();++i) 
                            {
                                expression_after_last_comma += one_line_file[i]; //n
                                if(one_line_file[i]     == ' ')    //1
                                    ++number_of_empty_char; // 1
                            }
                            //wyrazenie jest puste,  1
                            if(expression_after_last_comma.size() == number_of_empty_char){ 
                            }  
                            else{//wszystko ok z dana linijka pliku więc: zapis do tablicy 
                                ++number_of_save_expression; //1

                            if(number_of_save_expression%SIZE_OF_10K_DATA == 0 ){
                                stop = std::chrono::high_resolution_clock::now(); 
                                duration = std::chrono::duration_cast<std::chrono::milliseconds>
                                (stop - start); 
                                algorithm_complexity_saving_to_csv_file(
                                number_of_save_expression,
                                duration);     
                            }                                
                                     

                                #define SAVE_DATA_TO_STRUCT(number_of_data) \
                                    if(number_of_save_expression<= \
                                         SIZE_OF_##number_of_data##_DATA){ \
                                        _##number_of_data##_data[number_of_save_expression-1] \
                                        .number_of_ranking = \
                                        std::stof(expression_after_last_comma); \
                                        _##number_of_data##_data[number_of_save_expression-1] \
                                        .title = expression_before_last_comma; \
                                    }

                                    SAVE_DATA_TO_STRUCT(10K)  // O(n) 
                                    SAVE_DATA_TO_STRUCT(100K) // O(n) 
                                    SAVE_DATA_TO_STRUCT(200K) // O(n) 
                                    SAVE_DATA_TO_STRUCT(300K) // O(n) 
                                    SAVE_DATA_TO_STRUCT(400K) // O(n) 
                                    SAVE_DATA_TO_STRUCT(500K) // O(n)  
                                    SAVE_DATA_TO_STRUCT(600K) // O(n) 
                                    SAVE_DATA_TO_STRUCT(700K) // O(n)  
                                    SAVE_DATA_TO_STRUCT(800K) // O(n)  
                                    SAVE_DATA_TO_STRUCT(900K) // O(n) 
                                    SAVE_DATA_TO_STRUCT(1000K) // O(n) 

                                data_from_file data_temp; //1
                                data_temp.number_of_ranking = 
                                std::stof(expression_after_last_comma); //n
                                data_temp.title = expression_before_last_comma; //1
                                _MAX_data.push_back(data_temp); // O(1)
                            }                                
                        } 
                    }                         
                } 
            }  
        }
    }
    auto stop_filtring_duration = std::chrono::high_resolution_clock::now();   
    auto duration_filtring = std::chrono::duration_cast<std::chrono::milliseconds>(stop_filtring_duration - start_filtring_duration);  
    algorithm_complexity_saving_to_csv_file(_MAX_data.size(), duration_filtring);     
} 

void read_data_from_file::test_filtr_read_data_from_file(const char* name_of_file_temp)
{
    std::fstream file( name_of_file_temp, std::ios::in ); //zakładamy, że plik istnieje

    if(!file.good())
    { 
        std::cout<<"Nie mozna otworzyc pliku"<<std::endl;
    }

    unsigned int number_of_line_file = 0;        
    while (!file.eof())
    {
        std::string one_line_file;
        std::size_t found_comma_first;
        std::size_t found_comma_second;
        std::string expression_before_first_comma;
        std::string expression_before_second_comma;
        std::string expression_after_second_comma;

        ++number_of_line_file;
        getline( file, one_line_file ); //wczytanie CAŁEGO jednego wiersza danych
        found_comma_first = one_line_file.find(",");
        found_comma_second = one_line_file.find(",", found_comma_first+1);

        std::cout<<"----------------------------------------------------"<<std::endl;
        std::cout<<"one_line_file: "<<one_line_file<<std::endl;
        /*std::cout<<"found comma first: "<< found_comma_first<<std::endl;
        std::cout<<"found comma second: "<< found_comma_second<<std::endl;*/

        if(one_line_file[0] == ' ')
        {
            std::cout<<"Odrzucono "<<number_of_line_file<<" linie pliku"<<std::endl;
        }
        else{
            unsigned int number_of_empty_char = 0;           
            for(unsigned int i = 0; i<found_comma_first;++i)
            {
                expression_before_first_comma += one_line_file[i];
                if(one_line_file[i]     == ' ')    
                    ++number_of_empty_char;
            }
            std::cout<<expression_before_first_comma<<std::endl;  
            if(expression_before_first_comma.size() == number_of_empty_char) //wyrazenie jest puste
                    std::cout<<"Odrzucono "<<number_of_line_file<<" linie pliku"<<std::endl;
            else //sprawdzamy kolejne wyrazenie przed nastepnym przecinkiem
            {
                if(found_comma_first+1 == found_comma_second) //wyrazenie typu ,,cos tam   
                    std::cout<<"Odrzucono "<<number_of_line_file<<" linie pliku"<<std::endl;
                else
                {
                    number_of_empty_char = 0;
                    for(unsigned int i = found_comma_first+1; i<found_comma_second;++i)
                    {
                        expression_before_second_comma += one_line_file[i];
                        if(one_line_file[i]     == ' ')    
                            ++number_of_empty_char;
                    }       
                    std::cout<<expression_before_second_comma<<std::endl;  
                    if(expression_before_second_comma.size() == number_of_empty_char) //wyrazenie jest puste
                        std::cout<<"Odrzucono "<<number_of_line_file<<" linie pliku"<<std::endl;
                    else //sprawdzamy wyrazenie za drugim przecinikeim 
                    {
                        if(found_comma_second == one_line_file.size()-1) //po drugim przecinku nie ma juz nic 
                            std::cout<<"Odrzucono "<<number_of_line_file<<" linie pliku"<<std::endl;
                        else                            
                        {
                            number_of_empty_char = 0;
                            for(unsigned int i = found_comma_second+1; i<one_line_file.size();++i)
                            {
                                expression_after_second_comma += one_line_file[i];
                                if(one_line_file[i]     == ' ')    
                                    ++number_of_empty_char;
                            }     
                            std::cout<<expression_after_second_comma<<std::endl;  
                            if(expression_after_second_comma.size() == number_of_empty_char) //wyrazenie jest puste
                                std::cout<<"Odrzucono "<<number_of_line_file<<" linie pliku"<<std::endl;  
                            else{
                                std::cout<<"Wyrazenie okazało się prawidlowe wiec je zapisujemy"<<std::endl;
                                std::cout<<"----------------------------------------------------"<<std::endl;
                                //zapis do tablicy 
                            }                                
                        }                        
                    }                         
                } 
            }  
        }
    }
} 

void read_data_from_file::algorithm_complexity_saving_to_csv_file(unsigned int number_of_data, auto filtering_time)
{
    if( file_temp.good() ) 
    { 
        file_temp <<  number_of_data << ","<<filtering_time.count()<<std::endl; 
        file_temp.flush(); 
    } 
}        

read_data_from_file::~read_data_from_file()
{
    delete[] _10K_data;
    delete[] _100K_data;
    delete[] _200K_data;
    delete[] _300K_data;
    delete[] _400K_data;
    delete[] _500K_data;
    delete[] _600K_data;
    delete[] _700K_data;
    delete[] _800K_data;
    delete[] _900K_data;
    delete[] _1000K_data;
    file_temp.close();
}
/*read_data_from_file::read_data_from_file(unsigned int number_of_data_temp)
{
    _MAX_data = new data_from_file[number_of_data_temp];
}*/