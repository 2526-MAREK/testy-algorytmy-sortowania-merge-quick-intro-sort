#include "test_algorithm.hh"

int main(void)
{   
    //std::string literals_of_size_data[11] = {"10K","100K","200K","300K","400K","500K","600K","700K","800K","900K","1000K"};
    std::fstream file( "analiza_zloznosci_algorytmow.csv", std::ios::out );
    read_data_from_file obj_temp_2("projekt2_dane.csv");
    std::cout<<"------------------------------------------------------------------------"<<std::endl;
    TEST_ALGORITHM_BEGIN(merge, "merge", "projekt2_dane.csv")
    std::cout<<"------------------------------------------------------------------------"<<std::endl;
    TEST_ALGORITHM_BEGIN(quick, "quick", "projekt2_dane.csv")
    std::cout<<"------------------------------------------------------------------------"<<std::endl;
    TEST_ALGORITHM_BEGIN(intro, "intro", "projekt2_dane.csv")
    std::cout<<"------------------------------------------------------------------------"<<std::endl;
    file.close();
    /*std::cout<<"------------------------------------------"<<std::endl;
    std::cout<<"tablica przed posortowaniem: "<<std::endl;
    for(int i =0; i<SIZE_OF_10K_DATA;++i)
        std::cout<<data._10k_data[i].number_of_ranking<<" "<<data._10k_data[i].title<<std::endl;
    std::cout<<"------------------------------------------"<<std::endl;*/

    
    /*std::cout<<"tablica  po posortowaniu: "<<std::endl;
    for(int i =0; i<SIZE_OF_10K_DATA;++i)
        std::cout<<data._10k_data[i].number_of_ranking<<" "<<data._10k_data[i].title<<std::endl;
    std::cout<<"------------------------------------------"<<std::endl;           */
    return 0;
}